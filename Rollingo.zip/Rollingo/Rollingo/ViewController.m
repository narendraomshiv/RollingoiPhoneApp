//
//  ViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
  
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


@end
