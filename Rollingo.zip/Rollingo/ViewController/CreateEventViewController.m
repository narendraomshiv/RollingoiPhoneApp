//
//  CreateEventViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/29/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "CreateEventViewController.h"

@interface CreateEventViewController ()

@end

@implementation CreateEventViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
     [self.view setBackgroundColor:[UIColor colorWithRed:232/255.0 green:232/255.0 blue:232/255.0 alpha:1.0]];
    [self.headerLabel setText:@"CREATE EVENT"];
    [self createEventtttt];
  
}

-(void)createEventtttt
{
    UIImage *nameIcon = [UIImage imageNamed:@"nameicon_i5"];
    UIImage *dateIcon = [UIImage imageNamed:@"dateicon_i5"];
    UIImage *locatiobIcon = [UIImage imageNamed:@"locatoion_i5"];
    
    UILabel *haddingLabel = [self addlabelWithFrame:CGRectMake(0, self.navigationView.frame.size.height+20, self.view.frame.size.width, 40) font:[UIFont fontWithName:@"Hobo" size:20] text:@"Tell us more about your event"];
    [haddingLabel setTextColor:[UIColor darkGrayColor]];
    [haddingLabel setTextAlignment:NSTextAlignmentCenter];
    [self.view addSubview:haddingLabel];
    
    UITextField *nameTf = [self addTextFieldWithFrame:CGRectMake(15, haddingLabel.frame.origin.y+haddingLabel.frame.size.height+20, self.view.frame.size.width-30, 42) placeholder:@"Event name" tag:100 text:@""];
    [self.view addSubview:nameTf];
    
    UIButton *nameButton = [self addButtonWithFrame:CGRectMake(nameTf.frame.size.width-40, 0, 40, 42) title:nil tag:300 bgColor:[UIColor clearColor] font:nil];
    [nameButton setImage:nameIcon forState:UIControlStateNormal];
    [nameTf addSubview:nameButton];
    
    UITextField *dateTimeTf = [self addTextFieldWithFrame:CGRectMake(15, nameTf.frame.origin.y+nameTf.frame.size.height+20, self.view.frame.size.width-30, 42) placeholder:@"Set date & time" tag:100 text:@""];
    [self.view addSubview:dateTimeTf];
    
    UIButton *dateButton = [self addButtonWithFrame:CGRectMake(dateTimeTf.frame.size.width-40, 0, 40, 42) title:nil tag:301 bgColor:[UIColor clearColor] font:nil];
     [dateButton setImage:dateIcon forState:UIControlStateNormal];
    [dateTimeTf addSubview:dateButton];
    
    UITextField *locationTf = [self addTextFieldWithFrame:CGRectMake(15, dateTimeTf.frame.origin.y+dateTimeTf.frame.size.height+20, self.view.frame.size.width-30, 42) placeholder:@"Add location" tag:101 text:@""];
    [self.view addSubview:locationTf];
    
    UIButton *locationButton = [self addButtonWithFrame:CGRectMake(dateTimeTf.frame.size.width-40, 0, 40, 42) title:nil tag:302 bgColor:[UIColor clearColor] font:nil];
    [locationButton setImage:locatiobIcon forState:UIControlStateNormal];
    [locationTf addSubview:locationButton];
    
    //UIImage *checkImag = [UIImage imageNamed:@""];
    UIButton *checkBoxButton = [self addButtonWithFrame:CGRectMake(15, locationTf.frame.origin.y+locationTf.frame.size.height+10, 30, 30) title:nil tag:200 bgColor:[UIColor redColor] font:nil];
    [self.view addSubview:checkBoxButton];
    
    UILabel *checkboxlabel = [self addlabelWithFrame:CGRectMake(checkBoxButton.frame.origin.x+checkBoxButton.frame.size.width+5, locationTf.frame.origin.y+locationTf.frame.size.height+10, 150, 30) font:[UIFont systemFontOfSize:12] text:@"Show event location"];
    [checkboxlabel setTextColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0]];
    [self.view addSubview:checkboxlabel];
    
    UITextField *moreinfoTf = [self addTextFieldWithFrame:CGRectMake(15, checkBoxButton.frame.origin.y+checkBoxButton.frame.size.height+10, self.view.frame.size.width-30, 42) placeholder:@"More info" tag:102 text:@""];
    [self.view addSubview:moreinfoTf];
    
    UIImage *plusimage = [UIImage imageNamed:@"plus_i5"];
    UIButton *inviteFrndButton = [self addButtonWithFrame:CGRectMake(30, moreinfoTf.frame.origin.y+moreinfoTf.frame.size.height+20, self.view.frame.size.width-60, 42) title:@"Invite your friends" tag:201 bgColor:[UIColor clearColor] font:[UIFont fontWithName:@"Hobo" size:18]];
    [inviteFrndButton setTitleColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0] forState:UIControlStateNormal];
    [inviteFrndButton setImage:plusimage forState:UIControlStateNormal];
    [inviteFrndButton setImageEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
    [self.view addSubview:inviteFrndButton];
    
    UIButton *finishButton = [self addButtonWithFrame:CGRectMake(0, self.view.frame.size.height-45, self.view.frame.size.width, 45) title:@"FINISH" tag:202 bgColor:[UIColor redColor] font:[UIFont systemFontOfSize:14]];
    [self.view addSubview:finishButton];
    
    
}

-(UIImageView *)addImageViewWithFrame:(CGRect)frame bgImage:(UIImage *)bgImage
{
    UIImageView *imageView = [UIImageView new];
    [imageView setFrame:frame];
    [imageView setImage:bgImage];
    return imageView;
}

-(UILabel *)addlabelWithFrame:(CGRect)frame font:(UIFont *)font text:(NSString*)text
{
    UILabel * label = [[UILabel alloc]init];
    [label setFrame:frame];
    [label setFont:font];
    [label setText:text];
    return label;
    
}

-(UIView *)addViewWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor
{
    UIView *view = [UIView new];
    [view setFrame:frame];
    [view setBackgroundColor:bgColor];
    return view;
}


-(UIButton*)addButtonWithFrame:(CGRect)frame title:(NSString*)title tag:(int)tag bgColor:(UIColor*)bgColor font:(UIFont*)font
{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:frame];
    [button setTag:tag];
    [button setBackgroundColor:bgColor];
    [button addTarget:self action:@selector(buttonEAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font  = font;
    [button setTitle:title forState:UIControlStateNormal];
    return button;
}

-(UITextField*)addTextFieldWithFrame:(CGRect)Frame placeholder:(NSString*)placeholder tag:(NSInteger)tag text:(NSString*)text
{
    UITextField *textField=[UITextField new];
    [textField setFrame:Frame];
    [textField setTextColor:[UIColor blackColor]];
    [textField setPlaceholder:placeholder];
    [textField setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [textField setTag:tag];
    [textField setText:text];
    [textField setEnabled:YES];
    [textField setUserInteractionEnabled:YES];
   
    [textField setAutocorrectionType:UITextAutocorrectionTypeNo];
    [textField setFont:[UIFont fontWithName:@"Hobo" size:14]];
    [textField setTextColor:[UIColor blackColor]];
    [textField.layer setBorderWidth:1.2];
    textField.layer.borderColor=[[UIColor lightTextColor]CGColor];
    [textField setBackgroundColor:[UIColor whiteColor]];
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 15, 25)];
    textField.leftView = paddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
    [textField setDelegate:(id)self];
    
    return textField;
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(IBAction)buttonEAction:(UIButton*)sender
{
    if (sender.tag == 300)
    {
        NSLog(@"name");
    }
    else if (sender.tag == 301)
    {
        NSLog(@"date");
    }
    else if (sender.tag == 302)
    {
        NSLog(@"location");
    }
    else if (sender.tag == 200)
    {
        NSLog(@"checkbox");
    }
    else if (sender.tag == 201)
    {
        NSLog(@"inivate Frnd");
    }
    else if (sender.tag == 202)
    {
        NSLog(@"finish Button");
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}


@end
