//
//  EventRideViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "EventRideViewController.h"
#import "RideTableViewCell.h"

@interface EventRideViewController ()
{
    UITableView *rideTableView;
}

@end

@implementation EventRideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.headerLabel setText:@"RIDES"];
    
    [self rideViewww];
    
}

-(void)rideViewww
{
    rideTableView = [[UITableView alloc]init];
    rideTableView = [self addTableWithFrame:CGRectMake(0, self.navigationView.frame.size.height, self.view.frame.size.width, self.view.frame.size.height-self.navigationView.frame.size.height)tag:1000];
    
    [self.view addSubview:rideTableView];
    
}

-(UITableView *)addTableWithFrame:(CGRect)frame tag:(int)tag
{
    UITableView * tableView = [[UITableView alloc]init];
    [tableView setFrame:frame];
    [tableView setBackgroundColor:[UIColor clearColor]];
    [tableView setDelegate:(id)self];
    tableView.showsVerticalScrollIndicator = NO;
    [tableView setDataSource:(id)self];
    [tableView setTag:tag];
    
    return tableView;
}

#pragma mark UITableViewDelegate and UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 3;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier";
    RideTableViewCell *cell = (RideTableViewCell*)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell==nil)
    {
        cell=[[RideTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
          
    }
    
    UIImage *proImggggg = [UIImage imageNamed:@"main_i5"];
    [cell.profileImageView setFrame:CGRectMake(5, 6, 60, 60)];
    [cell.profileImageView setUserInteractionEnabled:YES];
    [cell.profileImageView setImage:proImggggg];
    
    [cell.timeLabel setFrame:CGRectMake(5, cell.profileImageView.frame.origin.y+cell.profileImageView.frame.size.height+3, 60, 20)];
    [cell.timeLabel setText:@"TODAY"];
    
    [cell.rideNameLabel setFrame:CGRectMake(cell.profileImageView.frame.origin.x+cell.profileImageView.frame.size.width+10, 10, 100, 20)];
   // [cell.rideNameLabel setBackgroundColor:[UIColor greenColor]];
    [cell.rideNameLabel setText:@"The Marcus Ride"];
    
 
    [cell.resionNameLabel setFrame:CGRectMake(cell.profileImageView.frame.origin.x+cell.profileImageView.frame.size.width+10, cell.rideNameLabel.frame.origin.y+cell.rideNameLabel.frame.size.height+2, 60, 20)];
    [cell.resionNameLabel setText:@"Petach Tikva >"];
   // [cell.resionNameLabel setBackgroundColor:[UIColor blueColor]];
    
    [cell.resiondecribeLabel setFrame:CGRectMake(cell.resionNameLabel.frame.origin.x+cell.resionNameLabel.frame.size.width+5, cell.rideNameLabel.frame.origin.y+cell.rideNameLabel.frame.size.height+1, 60, 20)];
    [cell.resiondecribeLabel setText:@"TAMAR Pestival"];
    //[cell.resiondecribeLabel setBackgroundColor:[UIColor grayColor]];
    
    [cell.scrollView setFrame:CGRectMake(cell.profileImageView.frame.origin.x+cell.profileImageView.frame.size.width+10, cell.resionNameLabel.frame.origin.y+cell.resionNameLabel.frame.size.height+5,130, 30)];
    [cell.scrollView setBackgroundColor:[UIColor clearColor]];
    
    UIImage *proImg = [UIImage imageNamed:@"profile_i5"];
    float dx =0, dy = 0, dw = 30, dh = 30;
    UIImageView  *profileImageView;
    for (int i = 0; i<4; i++)
    {
        profileImageView = [[UIImageView alloc]init];
        [profileImageView setFrame:CGRectMake(dx, dy, dw, dh)];
        [profileImageView setBackgroundColor:[UIColor clearColor]];
        [profileImageView.layer setCornerRadius:15.0];
        [profileImageView setImage:proImg];
        [cell.scrollView addSubview:profileImageView];
        
        dx = dx+dw+4;
    }

    UIView *line1 = [[UIView alloc]init];
    [line1 setFrame:CGRectMake(cell.scrollView.frame.origin.x+cell.scrollView.frame.size.width+5, 10, 1, 60)];
    [line1 setBackgroundColor:[UIColor grayColor]];
    [cell addSubview:line1];
    
    [cell.hoursetimeLabel setFrame:CGRectMake(line1.frame.origin.x+line1.frame.size.width+2, 10, 50, 60)];
    //[cell.hoursetimeLabel setBackgroundColor:[UIColor greenColor]];
    [cell.hoursetimeLabel setText:@"22:00 > 02:00 <"];
    [cell.hoursetimeLabel setNumberOfLines:0];
    
    
    
    UIView *line2 = [[UIView alloc]init];
    [line2 setFrame:CGRectMake(cell.hoursetimeLabel.frame.origin.x+cell.hoursetimeLabel.frame.size.width+2, 10, 1, 60)];
    [line2 setBackgroundColor:[UIColor grayColor]];
    [cell addSubview:line2];
    
  
    
    UIImage *rideImage = [UIImage imageNamed:@"rideeee_i5"];
    [cell.rideiconImageView setFrame:CGRectMake(cell.frame.size.width-40, 20, rideImage.size.width, rideImage.size.height)];
    [cell.rideiconImageView setUserInteractionEnabled:YES];
    [cell.rideiconImageView setImage:rideImage];
    //[cell.rideiconImageView setBackgroundColor:[UIColor blueColor]];
    
    
       return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)viewDidLayoutSubviews
{
    UITableView  *tableView = (UITableView *)[self.view viewWithTag:500];
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)])
    {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)])
    {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell*)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


@end
