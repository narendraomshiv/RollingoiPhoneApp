//
//  ProfileViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "ProfileViewController.h"
#import "ProfileTableViewCell.h"

@interface ProfileViewController ()
{
    UITableView *repotTableView;
    NSMutableArray *iconArray ;
     NSMutableArray *nameArray ;
}

@end

@implementation ProfileViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.headerLabel setText:@"PROFILE"];
    iconArray = [[NSMutableArray alloc]initWithObjects:@"vicalicon_i5",@"eventicon_i5",@"homeicon_i5",@"worldicon_i5", nil];
    nameArray = [[NSMutableArray alloc]initWithObjects:@"My Rides",@"My Events",@"Home Adress",@"English", nil];
    
    [self profileViewww];
    
}


-(void)profileViewww
{
    UIView *mainView = [self addViewWithFrame:CGRectMake(0, self.navigationView.frame.size.height, self.view.frame.size.width, 184) bgColor:[UIColor colorWithRed:248/255.0 green:248/255.0 blue:248/255.0 alpha:1.0]];
    [mainView setTag:1000];
    [self.view addSubview:mainView];
    
    UIImageView *profileImageview = [[UIImageView alloc]init];
    [profileImageview setFrame:CGRectMake(mainView.frame.size.width/2-50, 20, 100, 100)];
    [profileImageview.layer setBorderWidth:2.0];
    [profileImageview.layer setCornerRadius:50];
    [profileImageview.layer setBorderColor:[UIColor grayColor].CGColor];
    [profileImageview setBackgroundColor:[UIColor redColor]];
    [mainView addSubview:profileImageview];
    
    UILabel *nameLabel = [self addlabelWithFrame:CGRectMake(0, profileImageview.frame.origin.y+profileImageview.frame.size.height+10, mainView.frame.size.width, 30) font:[UIFont fontWithName:@"Hobo" size:18] text:@"Ori Chen"];
   
    [nameLabel setTextColor:[UIColor grayColor]];
    [nameLabel setTextAlignment:NSTextAlignmentCenter];
    [mainView addSubview:nameLabel];
    
    UIButton *reporButoon = [self addButtonWithFrame:CGRectMake(mainView.frame.size.width- 70, 15, 60, 30) title:@"Report" tag:100 bgColor:[UIColor clearColor] font:[UIFont systemFontOfSize:14]];
    [reporButoon.layer setCornerRadius:5.0];
    [reporButoon setTitleColor:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0] forState:UIControlStateNormal];
    [reporButoon.layer setBorderWidth:1.0];
    [reporButoon.layer setBorderColor:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0].CGColor];
    [mainView addSubview:reporButoon];
    
    UIImage *facbkImag = [UIImage imageNamed:@"facebook_i5"];
    
    UIButton *facebookButton = [self addButtonWithFrame:CGRectMake(mainView.frame.size.width- 50, mainView.frame.size.height-40,facbkImag.size.width, facbkImag.size.height) title:nil tag:101 bgColor:[UIColor clearColor] font:nil];
    [facebookButton setImage:facbkImag forState:UIControlStateNormal];
    [mainView addSubview:facebookButton];
    
    UIImage *likeImag = [UIImage imageNamed:@"done_i5"];
    
    UIButton *likeButton = [self addButtonWithFrame:CGRectMake(self.view.frame.size.width/2-likeImag.size.width-20, mainView.frame.origin.y+mainView.frame.size.height+30,likeImag.size.width, likeImag.size.height) title:nil tag:102 bgColor:[UIColor clearColor] font:nil];
    [likeButton setImage:likeImag forState:UIControlStateNormal];
    [self.view addSubview:likeButton];
    
    UIImage *stringImag = [UIImage imageNamed:@"string_i5"];
    
    UIButton *stringButton = [self addButtonWithFrame:CGRectMake(self.view.frame.size.width/2+20, mainView.frame.origin.y+mainView.frame.size.height+30,stringImag.size.width, stringImag.size.height) title:nil tag:103 bgColor:[UIColor clearColor] font:nil];
    [stringButton setImage:stringImag forState:UIControlStateNormal];
    [self.view addSubview:stringButton];
    
    
    NSString *str=@"RIDE : 55";
    UILabel *rideLabel = [self addlabelWithFrame:CGRectMake(0, likeButton.frame.origin.y+likeButton.frame.size.height+20, self.view.frame.size.width/2, 40) font:[UIFont systemFontOfSize:16] text:nil];
    [rideLabel setTag:104];
    [rideLabel setTextColor:[UIColor grayColor]];
    [rideLabel setTextAlignment:NSTextAlignmentCenter];
    
    NSMutableAttributedString *attributedString=[[NSMutableAttributedString alloc]initWithString:str];
    [attributedString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0] range:[str rangeOfString:@"55"]];
    [rideLabel setAttributedText:attributedString];
    [self.view addSubview:rideLabel];
    
    
     NSString *string=@"DRIVER : 22";
    UILabel *driverLabel = [self addlabelWithFrame:CGRectMake(self.view.frame.size.width/2, stringButton.frame.origin.y+stringButton.frame.size.height+20, self.view.frame.size.width/2, 40) font:[UIFont systemFontOfSize:16] text:nil];
    [driverLabel setTextColor:[UIColor grayColor]];
    [driverLabel setTag:105];
    [driverLabel setTextAlignment:NSTextAlignmentCenter];
    
    NSMutableAttributedString *attributedStringg=[[NSMutableAttributedString alloc]initWithString:string];
    [attributedStringg addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0] range:[string rangeOfString:@"22"]];
    [driverLabel setAttributedText:attributedStringg];
    
    [self.view addSubview:driverLabel];
    
}


-(UIImageView *)addImageViewWithFrame:(CGRect)frame bgImage:(UIImage *)bgImage
{
    UIImageView *imageView = [UIImageView new];
    [imageView setFrame:frame];
    [imageView setImage:bgImage];
    return imageView;
}

-(UILabel *)addlabelWithFrame:(CGRect)frame font:(UIFont *)font text:(NSString*)text
{
    UILabel * label = [[UILabel alloc]init];
    [label setFrame:frame];
    [label setFont:font];
    [label setText:text];
    return label;
    
}

-(UIView *)addViewWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor
{
    UIView *view = [UIView new];
    [view setFrame:frame];
    [view setBackgroundColor:bgColor];
    return view;
}


-(UIButton*)addButtonWithFrame:(CGRect)frame title:(NSString*)title tag:(int)tag bgColor:(UIColor*)bgColor font:(UIFont*)font
{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:frame];
    [button setTag:tag];
    [button setBackgroundColor:bgColor];
    
    [button addTarget:self action:@selector(profilebuttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font  = font;
    [button setTitle:title forState:UIControlStateNormal];
    return button;
}

-(IBAction)profilebuttonAction:(UIButton*)sender
{
    if (sender.tag == 100)
    {
        NSLog(@"Report Button");
        //[self reportButtonView];
        
        
        
    }
    else if (sender.tag == 101)
    {
        NSLog(@"Facebook Button");
    }
    else if (sender.tag == 102)
    {
        NSLog(@"Like Button");
    }
    else if (sender.tag == 103)
    {
        NSLog(@"Driver Button");
    }
}


//======================================= Report  button ============

-(void)reportButtonView
{
    UIView *mainView = (UIView*)[self.view viewWithTag:1000];
    
    UIView *reportView = [self addViewWithFrame:CGRectMake(0, mainView.frame.origin.y+mainView.frame.size.height+5, self.view.frame.size.width, 160) bgColor:[UIColor grayColor]];
    [reportView setTag:1001];
    [self.view addSubview:reportView];
    
    repotTableView = [self addTableWithFrame:CGRectMake(0, 0, reportView.frame.size.width, reportView.frame.size.height)tag:1002];
    
    [reportView addSubview:repotTableView];


}


-(UITableView *)addTableWithFrame:(CGRect)frame tag:(int)tag
{
    UITableView * tableView = [[UITableView alloc]init];
    [tableView setFrame:frame];
    [tableView setBackgroundColor:[UIColor clearColor]];
    [tableView setDelegate:(id)self];
    tableView.showsVerticalScrollIndicator = NO;
    [tableView setDataSource:(id)self];
    [tableView setTag:tag];
    
    return tableView;
}

#pragma mark UITableViewDelegate and UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return iconArray.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier";
    ProfileTableViewCell *cell = (ProfileTableViewCell*)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell==nil)
    {
        cell=[[ProfileTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    
    UIImage *iconImage = [UIImage imageNamed:[iconArray objectAtIndex:indexPath.row]];
   
    [cell.iconView setFrame:CGRectMake(15, cell.frame.size.height/2-iconImage.size.height/2, iconImage.size.width, iconImage.size.height)];
    [cell.iconView setUserInteractionEnabled:YES];
    [cell.iconView setImage:iconImage];
    
    [cell.eventLabel setText:[nameArray objectAtIndex:indexPath.row]];
    

    [cell.eventLabel setFrame:CGRectMake(cell.iconView.frame.origin.x+cell.iconView.frame.size.width+15, 5, 150, 30)];
    [cell.eventLabel setTag:104];
    
    [cell.eventLabel setTextAlignment:NSTextAlignmentLeft];
    
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)viewDidLayoutSubviews
{
    UITableView  *tableView = (UITableView *)[self.view viewWithTag:500];
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)])
    {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)])
    {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell*)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
  
}



@end
