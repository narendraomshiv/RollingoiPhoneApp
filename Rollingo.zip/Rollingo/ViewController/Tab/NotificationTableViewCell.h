//
//  NotificationTableViewCell.h
//  Rollingo
//
//  Created by Popin kumar on 5/29/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationTableViewCell : UITableViewCell

@property (nonatomic, strong)UIImageView * profileImageView;
@property (nonatomic, strong)UILabel * profileNameLabel;
@property (nonatomic, strong)UILabel * timeLabel;
@property (nonatomic, strong)UILabel * masgLabel;

@property (nonatomic, strong)UIButton * approveButton;
@property (nonatomic, strong)UIButton * rejectButton;


@end
