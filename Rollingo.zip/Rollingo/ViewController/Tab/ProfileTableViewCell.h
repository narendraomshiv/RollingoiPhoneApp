//
//  ProfileTableViewCell.h
//  Rollingo
//
//  Created by Popin kumar on 5/29/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileTableViewCell : UITableViewCell

@property (nonatomic,strong)UIImageView *iconView;
@property (nonatomic,strong)UILabel *eventLabel;

@end
