//
//  ProfileTableViewCell.m
//  Rollingo
//
//  Created by Popin kumar on 5/29/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "ProfileTableViewCell.h"

@implementation ProfileTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
 
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        self.iconView = [[UIImageView alloc]init];
     
        [self addSubview:self.iconView];
        
        self.eventLabel =[[UILabel alloc]init];
        [self.eventLabel setFont:[UIFont systemFontOfSize:12]];
        [self.eventLabel setTextAlignment:NSTextAlignmentCenter];
        [self.eventLabel setTextColor:[UIColor grayColor]];
        [self addSubview:self.eventLabel];
  
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
}


@end
