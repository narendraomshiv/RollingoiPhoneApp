//
//  RideTableViewCell.h
//  Rollingo
//
//  Created by Popin kumar on 5/23/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RideTableViewCell : UITableViewCell

@property (nonatomic, strong)UIImageView * profileImageView;
@property (nonatomic, strong)UILabel * rideNameLabel;
@property (nonatomic, strong)UILabel * timeLabel;
@property (nonatomic, strong)UILabel * resionNameLabel;
@property (nonatomic, strong)UILabel * resiondecribeLabel;
@property(nonatomic, strong)UIScrollView *scrollView;
@property (nonatomic, strong)UILabel * hoursetimeLabel;

@property (nonatomic, strong)UIImageView * scrollImageView;
@property (nonatomic, strong)UIImageView * rideiconImageView;


@end

