//
//  HomeEventViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "HomeEventViewController.h"
#import "HomeTableViewCell.h"
#import "CreateEventViewController.h"

@interface HomeEventViewController ()
{
    UIScrollView * headerScroller;
    UIScrollView * homeScroller;
    UITableView *nearTableView;
    UITableView *savedTableView;
    UITableView *popularTableView;
    UIView *underline;
    BOOL isSearchEnable;
    
    NSMutableArray *searchResultArray;
    
    NSMutableArray * nearArr;
    NSMutableArray * savedArr;
    NSMutableArray * popularArr;
    NSMutableArray * commonArr;
 
}

@end

@implementation HomeEventViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor colorWithRed:232/255.0 green:232/255.0 blue:232/255.0 alpha:1.0]];
    
    [self.headerLabel setHidden:YES];
    [self.backButton setHidden:YES];
    
    [self navigationMethod];
    
    [self addScrollView];
}

-(void)navigationMethod
{
    UITextField *SearchText=[[UITextField alloc]initWithFrame:CGRectMake(15, self.navigationView.frame.size.height/2-20, self.view.frame.size.width/2+30, 40)];
    SearchText.backgroundColor=[UIColor clearColor];
    [SearchText setValue:[UIColor whiteColor ] forKeyPath:@"_placeholderLabel.textColor"];
    SearchText.placeholder=@"Where you wanna go?";
    [SearchText setTag:5];
    [SearchText setFont:[UIFont systemFontOfSize:14]];
    SearchText.textColor=[UIColor whiteColor];
    //[SearchText.layer setCornerRadius:4.0];
    [SearchText resignFirstResponder];
    [SearchText setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 10, 35, 25)];
    SearchText.leftView = paddingView;
    SearchText.leftViewMode = UITextFieldViewModeAlways;
    [SearchText setDelegate:(id)self];
    [self.navigationView addSubview: SearchText];
    
    UIImage *serchIcon = [UIImage imageNamed:@"search_i5"];
    UIImageView *serchImgView = [self addImageViewWithFrame:CGRectMake(0, 10, serchIcon.size.width, serchIcon.size.height) bgImage:serchIcon];
    [SearchText addSubview:serchImgView];
    
    UIView *lineView = [self addViewWithFrame:CGRectMake(0, SearchText.frame.size.height-5, SearchText.frame.size.width, 1.0) bgColor:[UIColor whiteColor]];
    [SearchText addSubview:lineView];
    
    UIImage *eventIcon = [UIImage imageNamed:@"eventplusicon_i5"];
    UIButton *eventButton = [self addButtonWithFrame:CGRectMake(self.navigationView.frame.size.width-100, self.navigationView.frame.size.height/2-20, 90, 30) title:@"EVENT" tag:6 bgColor:[UIColor clearColor] font:[UIFont systemFontOfSize:12]];
    [eventButton.layer setBorderWidth:1];
    [eventButton.layer setCornerRadius:5.0];
    [eventButton setImage:eventIcon forState:UIControlStateNormal];
    [eventButton.layer setBorderColor:[UIColor whiteColor].CGColor];
    
    //  [faceebookButton setImageEdgeInsets:UIEdgeInsetsMake(<#CGFloat top#>, <#CGFloat left#>, <#CGFloat bottom#>, <#CGFloat right#>)];
    [eventButton setImageEdgeInsets:UIEdgeInsetsMake(0, -15, 0, 0)];
    [eventButton setTitleEdgeInsets:UIEdgeInsetsMake(0, 5, 0, 0)];
    [self.navigationView addSubview:eventButton];

}


-(void)addScrollView
{
    headerScroller = [[UIScrollView alloc]init];
    [headerScroller setFrame:CGRectMake(0, self.navigationView.frame.size.height, self.view.frame.size.width, 40)];
    [headerScroller setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"head_i5"]]];
    [headerScroller setDelegate:(id)self];
    [headerScroller setPagingEnabled:YES];
    
    //[headerScroller setContentOffset:CGPointMake(100, 0) animated:YES];
    
    [headerScroller setTag:555];
    [self.view addSubview:headerScroller];
    
    homeScroller = [[UIScrollView alloc]init];
    [homeScroller setFrame:CGRectMake(0, headerScroller.frame.origin.y+headerScroller.frame.size.height+15, self.view.frame.size.width, self.view.frame.size.height-self.navigationView.frame.size.height-headerScroller.frame.size.height)];
    [homeScroller setBackgroundColor:[UIColor redColor]];
    [homeScroller setContentSize:CGSizeMake(960.0, 0)];
    [homeScroller setBounces:NO];
    
    [homeScroller setContentOffset:CGPointMake(homeScroller.contentOffset.x+320, 0) animated:YES];
    [homeScroller setDelegate:(id)self];
    [homeScroller setPagingEnabled:YES];
    [self.view addSubview:homeScroller];
    
    [self nearView];
    [self savedView];
    [self popularView];
    
}

-(void)nearView
{
    UIView *  nearView = [[UIView alloc]init];
    [nearView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-self.navigationView.frame.size.height-headerScroller.frame.size.height)];
    [nearView setBackgroundColor:[UIColor whiteColor]];
    [homeScroller addSubview:nearView];
    
    nearTableView = [self addTableWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-(self.navigationView.frame.size.height+headerScroller.frame.size.height))tag:501];
  
    [homeScroller addSubview:nearTableView];
}

-(void)savedView
{
    
    UIFont *font = [UIFont fontWithName:@"Montserrat-Regular" size:12];
    UIButton *nearButton = [self addButtonWithFrame:CGRectMake(0, 0, 320/3, headerScroller.frame.size.height) title:@"NEAR" tag:1001 bgColor:[UIColor clearColor] font:font];
    [headerScroller addSubview:nearButton];
    
    underline=[[UIView alloc]initWithFrame:CGRectMake(10.0, headerScroller.frame.size.height-2, 93, 2)];
    [underline setBackgroundColor:[UIColor whiteColor]];
    [headerScroller addSubview:underline];
    
    UIButton *savedButton = [self addButtonWithFrame:CGRectMake(nearButton.frame.origin.x+nearButton.frame.size.width, 0, 320/3, headerScroller.frame.size.height) title:@"SAVED" tag:1002 bgColor:[UIColor clearColor] font:font];
    [headerScroller addSubview:savedButton];
    
    UIButton *popularButton = [self addButtonWithFrame:CGRectMake(savedButton.frame.origin.x+savedButton.frame.size.width, 0, 320/3, headerScroller.frame.size.height) title:@"POPULAR" tag:1003 bgColor:[UIColor clearColor] font:font];
    [headerScroller addSubview:popularButton];
    
    
    UIView * savedView = [[UIView alloc]init];
    [savedView setFrame:CGRectMake(320, 0, self.view.frame.size.width, self.view.frame.size.height-self.navigationView.frame.size.height-headerScroller.frame.size.height)];
    [savedView setBackgroundColor:[UIColor whiteColor]];
    [homeScroller addSubview:savedView];
    
    savedTableView = [self addTableWithFrame:CGRectMake(320, 0, self.view.frame.size.width, self.view.frame.size.height-(self.navigationView.frame.size.height+headerScroller.frame.size.height))tag:506];
   
    [homeScroller addSubview:savedTableView];
}

-(void)popularView
{
    UIView * popularView = [[UIView alloc]init];
    [popularView setFrame:CGRectMake(640, 0, self.view.frame.size.width, self.view.frame.size.height-self.navigationView.frame.size.height-headerScroller.frame.size.height)];
    [popularView setBackgroundColor:[UIColor whiteColor]];
    [homeScroller addSubview:popularView];
    
    popularTableView = [self addTableWithFrame:CGRectMake(640, 0, self.view.frame.size.width, self.view.frame.size.height-(self.navigationView.frame.size.height+headerScroller.frame.size.height))tag:600];
    [nearTableView setBackgroundColor:[UIColor whiteColor]];
    [homeScroller addSubview:popularTableView];
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (homeScroller.contentOffset.x==0)
    {
        isSearchEnable = NO;
        [underline setFrame:CGRectMake(10.0, headerScroller.frame.size.height-2, 93, 2)];
        self.type=Near;
        [nearTableView reloadData];
    }
    if (homeScroller.contentOffset.x==320)
    {
        isSearchEnable = NO;
        [underline setFrame:CGRectMake(113, headerScroller.frame.size.height-2,  94, 2)];
        self.type=Saved;
        [savedTableView reloadData];
    }
    if (homeScroller.contentOffset.x==640)
    {
        isSearchEnable = NO;
        [underline setFrame:CGRectMake(217, headerScroller.frame.size.height-2, 93, 2)];
        self.type=Popular;
        [popularTableView reloadData];
    }
    
}


-(IBAction)buttonAction:(UIButton *)sender
{
    headerScroller=(UIScrollView *)[self.view viewWithTag:555];
    
    if (sender.tag == 1001) // Near
    {
        isSearchEnable = NO;
        [homeScroller setContentOffset:CGPointMake(0, 0) animated:YES];
        [underline setFrame:CGRectMake(10.0, headerScroller.frame.size.height-2, 93, 2)];
        
        self.type=Near;
        [nearTableView reloadData];
        
    }
    if (sender.tag == 1002) // saved
    {
        isSearchEnable = NO;
        [homeScroller setContentOffset:CGPointMake(320, 0) animated:YES];
        [underline setFrame:CGRectMake(113, headerScroller.frame.size.height-2,  94, 2)];
        
        self.type=Saved;
        [savedTableView reloadData];
    }
    if (sender.tag == 1003) // Popular
    {
        isSearchEnable = NO;
        [homeScroller setContentOffset:CGPointMake(640, 0) animated:YES];
        [underline setFrame:CGRectMake(217, headerScroller.frame.size.height-2, 93, 2)];
        self.type=Popular;
        [popularTableView reloadData];
    }
    else if (sender.tag == 6)
    {
        NSLog(@"Events Button");
        
        CreateEventViewController *event = [CreateEventViewController new];
        [self.navigationController pushViewController:event animated:NO];
        
        
    }
 
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


-(UITableView *)addTableWithFrame:(CGRect)frame tag:(int)tag
{
    UITableView * tableView = [[UITableView alloc]init];
    [tableView setFrame:frame];
    [tableView setBackgroundColor:[UIColor clearColor]];
    [tableView setDelegate:(id)self];
    tableView.showsVerticalScrollIndicator = NO;
    [tableView setDataSource:(id)self];
    [tableView setTag:tag];
    [tableView setSeparatorColor:[UIColor whiteColor]];
    //[tableView setSeparatorColor:[UIColor grayColor]];
    return tableView;
}

-(UIImageView *)addImageViewWithFrame:(CGRect)frame bgImage:(UIImage *)bgImage
{
    UIImageView *imageView = [UIImageView new];
    [imageView setFrame:frame];
    [imageView setImage:bgImage];
    return imageView;
}

-(UILabel *)addlabelWithFrame:(CGRect)frame font:(UIFont *)font text:(NSString*)text
{
    UILabel * label = [[UILabel alloc]init];
    [label setFrame:frame];
    [label setFont:font];
    [label setText:text];
    return label;
    
}

-(UIView *)addViewWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor
{
    UIView *view = [UIView new];
    [view setFrame:frame];
    [view setBackgroundColor:bgColor];
    return view;
}


-(UIButton*)addButtonWithFrame:(CGRect)frame title:(NSString*)title tag:(int)tag bgColor:(UIColor*)bgColor font:(UIFont*)font
{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:frame];
    [button setTag:tag];
    [button setBackgroundColor:bgColor];
    
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font  = font;
    [button setTitle:title forState:UIControlStateNormal];
    return button;
}

#pragma mark UITableViewDelegate and UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 220;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
//    if (self.type==Near)
//    {
//        return isSearchEnable?searchResultArray.count:[nearArr count];
//    }
//    else if (self.type == Saved)
//    {
//        
//        return isSearchEnable?searchResultArray.count:[savedArr count];
//    }
//    
//    else
//        
//        return isSearchEnable?searchResultArray.count:[popularArr count];
    
    
    return 5;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier";
    HomeTableViewCell *cell = (HomeTableViewCell*)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell==nil)
    {
        cell=[[HomeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [cell.fullcellView setFrame:CGRectMake(5, 0, cell.frame.size.width-10, 210)];
        
    }
    
    if (self.type == Near)
    {
        
        commonArr= isSearchEnable?searchResultArray:nearArr;
    }
    
    else if (self.type == Saved)
    {

        commonArr = isSearchEnable?searchResultArray:savedArr;
    }
    
    else if (self.type == Popular)
    {
       
        commonArr = isSearchEnable?searchResultArray:popularArr;
    }
    
    UIImage *goingIconImg = [UIImage imageNamed:@"going_i5"];
    UIImage *mutualIconImg = [UIImage imageNamed:@"mutulR_i5"];
    UIImage *rideIconImg = [UIImage imageNamed:@"rideR_i5"];
    
    UIImage *mainImage = [UIImage imageNamed:@"mainImag_i5"];
    [cell.resturantImageView setFrame:CGRectMake(10, 10, cell.fullcellView.frame.size.width-20, 110)];
    [cell.resturantImageView setUserInteractionEnabled:YES];
    [cell.resturantImageView setImage:mainImage];
    
    
    
    [cell.restaurantNameLabel setFrame:CGRectMake(0, cell.resturantImageView.frame.size.height/2-10, cell.resturantImageView.frame.size.width, 20)];
    [cell.restaurantNameLabel setText:@"Clara - Students Line"];
    
    [cell.timeLabel setFrame:CGRectMake(0, cell.restaurantNameLabel.frame.origin.y+cell.restaurantNameLabel.frame.size.height+5, cell.resturantImageView.frame.size.width, 20)];
    [cell.timeLabel setText:@"THU 19 JAN - 13:00"];
    
    UIImage *dilImage = [UIImage imageNamed:@"dilIcon_i5"];
    [cell.dilButton setFrame:CGRectMake(cell.resturantImageView.frame.size.width-40, 10, dilImage.size.width, dilImage.size.height)];
    [cell.dilButton setImage:dilImage forState:UIControlStateNormal];
    [cell.dilButton addTarget:self action:@selector(dilButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [cell.dilButton setBackgroundColor:[UIColor clearColor]];

    
    [cell.showiconView setFrame:CGRectMake(30, cell.resturantImageView.frame.origin.y+cell.resturantImageView.frame.size.height+5, cell.fullcellView.frame.size.width-60, 40)];
    
    [cell.goingImageView setFrame:CGRectMake(0, 7, goingIconImg.size.width, goingIconImg.size.height)];
    [cell.goingImageView setImage:goingIconImg];
    [cell.goingLabel setFrame:CGRectMake(cell.goingImageView.frame.origin.x+cell.goingImageView.frame.size.width+5, 0, 60, 30)];
    [cell.goingLabel setText:@"250 Going"];
    
    [cell.mutualImageView setFrame:CGRectMake(cell.showiconView.frame.size.width/2-mutualIconImg.size.width/2-25, 7, mutualIconImg.size.width, mutualIconImg.size.height)];
    [cell.mutualImageView setImage:mutualIconImg];
    [cell.mutualLabel setFrame:CGRectMake(cell.mutualImageView.frame.origin.x+cell.mutualImageView.frame.size.width+5, 0, 50, 30)];
    [cell.mutualLabel setText:@"2 Mutual"];
    
    [cell.rideImageView setFrame:CGRectMake(cell.showiconView.frame.size.width/2+cell.showiconView.frame.size.width/3-rideIconImg.size.width/2-25, 7, rideIconImg.size.width, rideIconImg.size.height)];
    [cell.rideImageView setImage:rideIconImg];
    [cell.rideLabel setFrame:CGRectMake(cell.rideImageView.frame.origin.x+cell.rideImageView.frame.size.width+5, 0, 50, 30)];
    [cell.rideLabel setText:@"5 Ride"];
    
    [cell.scrollView setFrame:CGRectMake(30, cell.resturantImageView.frame.origin.y+cell.resturantImageView.frame.size.height+40, cell.fullcellView.frame.size.width-60+20, 40)];
    [cell.scrollView setBackgroundColor:[UIColor clearColor]];
    UIImage *proImg = [UIImage imageNamed:@"profile_i5"];
    float dx =0, dy = 0, dw = 40, dh = 40;
    UIImageView  *profileImageView;
    for (int i = 0; i<5; i++)
    {
         profileImageView = [[UIImageView alloc]init];
        [profileImageView setFrame:CGRectMake(dx, dy, dw, dh)];
        [profileImageView setBackgroundColor:[UIColor redColor]];
        [profileImageView.layer setCornerRadius:20.0];
        [profileImageView setImage:proImg];
        [cell.scrollView addSubview:profileImageView];
        
        dx = dx+dw+5;
    }
    UIImage *scrolButtonImage = [UIImage imageNamed:@"scrollbuIcon_i5"];
    [cell.scrollButton setFrame:CGRectMake(profileImageView.frame.origin.x+profileImageView.frame.size.width+5, 0, 40, 40)];
    [cell.scrollButton setImage:scrolButtonImage forState:UIControlStateNormal];
    [cell.scrollButton addTarget:self action:@selector(scrollbuttonAction:) forControlEvents:UIControlEventTouchUpInside];
     
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)viewDidLayoutSubviews
{
    UITableView  *tableView = (UITableView *)[self.view viewWithTag:500];
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)])
    {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)])
    {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell*)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(IBAction)scrollbuttonAction:(UIButton*)sender
{
    NSLog(@"ScroolButton Action");
    
}

-(IBAction)dilButtonAction:(UIButton*)sender
{
    NSLog(@"dilbuttonAction Action");
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
  
}



@end
