//
//  HomeTableViewCell.h
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell : UITableViewCell

@property (nonatomic, strong)UIView * fullcellView;
@property (nonatomic, strong)UIImageView * resturantImageView;
@property (nonatomic, strong)UILabel * restaurantNameLabel;
@property (nonatomic, strong)UILabel * timeLabel;

@property (nonatomic, strong)UIView * showiconView;

@property (nonatomic, strong)UIImageView * goingImageView;
@property (nonatomic, strong)UILabel * goingLabel;
@property (nonatomic, strong)UIImageView * mutualImageView;
@property (nonatomic, strong)UILabel * mutualLabel;
@property (nonatomic, strong)UIImageView * rideImageView;
@property (nonatomic, strong)UILabel * rideLabel;


@property(nonatomic, strong)UIScrollView *scrollView;
@property (nonatomic, strong)UIButton * scrollButton;


@property (nonatomic, strong)UIButton * dilButton;
//@property (nonatomic, strong)UIButton * lockButton;

@end
