//
//  NotificationViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "NotificationViewController.h"
#import "NotificationTableViewCell.h"

@interface NotificationViewController ()
{
    UITableView *notiFtiontableView;
}

@end

@implementation NotificationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.headerLabel setText:@"NOTIFICATIONS"];
    
    [self notificationView];
   
}


-(void)notificationView
{

    notiFtiontableView = [self addTableWithFrame:CGRectMake(0, self.navigationView.frame.size.height, self.view.frame.size.width, self.view.frame.size.height-self.navigationView.frame.size.height)tag:1000];
    
    [self.view addSubview:notiFtiontableView];
    
}

-(UITableView *)addTableWithFrame:(CGRect)frame tag:(int)tag
{
    UITableView * tableView = [[UITableView alloc]init];
    [tableView setFrame:frame];
    [tableView setBackgroundColor:[UIColor clearColor]];
    [tableView setDelegate:(id)self];
    tableView.showsVerticalScrollIndicator = NO;
    [tableView setDataSource:(id)self];
    [tableView setTag:tag];
    
    return tableView;
}

#pragma mark UITableViewDelegate and UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 4;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier";
    NotificationTableViewCell *cell = (NotificationTableViewCell*)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell==nil)
    {
        cell=[[NotificationTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    
    UIImage *proImggggg = [UIImage imageNamed:@"main_i5"];
    [cell.profileImageView setFrame:CGRectMake(5, 10, 60, 60)];
    [cell.profileImageView setUserInteractionEnabled:YES];
    [cell.profileImageView setImage:proImggggg];
    
    // [cell.rideNameLabel setBackgroundColor:[UIColor greenColor]];
    [cell.masgLabel setText:@"Amir Haim"];
    
    NSString *str=@"Amir Haim request to join your ride to KLARA - Student line";
    [cell.masgLabel setFrame:CGRectMake(cell.profileImageView.frame.origin.x+cell.profileImageView.frame.size.width+10, 10, 200, 30)];
    [cell.masgLabel setTag:104];
    [cell.masgLabel setNumberOfLines:0];
   // [cell.masgLabel setBackgroundColor:[UIColor redColor]];
     
    [cell.masgLabel setTextAlignment:NSTextAlignmentCenter];
    
    NSMutableAttributedString *attributedString=[[NSMutableAttributedString alloc]initWithString:str];
    [attributedString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0] range:[str rangeOfString:@"Amir Haim"]];
    [cell.masgLabel setAttributedText:attributedString];
    //[self.view addSubview:cell.masgLabel];
    
    [cell.timeLabel setFrame:CGRectMake(cell.profileImageView.frame.origin.x+cell.profileImageView.frame.size.width+10, cell.masgLabel.frame.origin.y+cell.masgLabel.frame.size.height+10, 60, 30)];
    [cell.timeLabel setText:@"1 hour ago"];
    
    
    [cell.approveButton setFrame:CGRectMake(cell.timeLabel.frame.origin.x+cell.timeLabel.frame.size.width+10, cell.masgLabel.frame.origin.y+cell.masgLabel.frame.size.height+8, 80, 30)];
    [cell.approveButton.layer setBorderWidth:1.0];
    [cell.approveButton.layer setBorderColor:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0].CGColor];
    [cell.approveButton.layer setCornerRadius:5.0];
    [cell.approveButton.titleLabel setFont:[UIFont systemFontOfSize:10]];
    [cell.approveButton setTitle:@"APPROVE" forState:UIControlStateNormal];
    [cell.approveButton addTarget:self action:@selector(approveButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [cell.approveButton setTitleColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0] forState:UIControlStateNormal];
    
    [cell.rejectButton setFrame:CGRectMake(cell.approveButton.frame.origin.x+cell.approveButton.frame.size.width+5, cell.masgLabel.frame.origin.y+cell.masgLabel.frame.size.height+8, 80, 30)];
    [cell.rejectButton.layer setBorderWidth:1.0];
    [cell.rejectButton.layer setBorderColor:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0].CGColor];
    [cell.rejectButton.layer setCornerRadius:5.0];
    [cell.rejectButton.titleLabel setFont:[UIFont systemFontOfSize:10]];
    [cell.rejectButton setTitle:@"REJECT" forState:UIControlStateNormal];
    [cell.rejectButton addTarget:self action:@selector(rejectButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [cell.rejectButton setTitleColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0] forState:UIControlStateNormal];
    
    
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)viewDidLayoutSubviews
{
    UITableView  *tableView = (UITableView *)[self.view viewWithTag:500];
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)])
    {
        [tableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)])
    {
        [tableView setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell*)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(IBAction)approveButtonAction:(UIButton*)sender
{
    NSLog(@"Approve button");
}
-(IBAction)rejectButtonAction:(UIButton*)sender
{
    NSLog(@"reJectButton");
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


@end
