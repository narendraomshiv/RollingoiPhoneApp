//
//  AroundViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "AroundViewController.h"
#import "AppDelegate.h"

#define kAppDelegate (AppDelegate *)[[UIApplication sharedApplication] delegate]

@interface AroundViewController ()
{
    MKMapView *mapKitView;
}

@end

@implementation AroundViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self aroundView];
}

-(void)aroundView
{
    UIView *searchView = [[UIView alloc]init];
    [searchView setFrame:CGRectMake(0, 0, self.view.frame.size.width, 100)];
    [searchView setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:searchView];
    
    UITextField *SearchText=[[UITextField alloc]initWithFrame:CGRectMake(15, 10, searchView.frame.size.width-30, 30)];
    SearchText.backgroundColor=[UIColor grayColor];
    [SearchText setValue:[UIColor whiteColor ] forKeyPath:@"_placeholderLabel.textColor"];
    SearchText.placeholder=@"Search";
    [SearchText setTag:5];
    [SearchText setFont:[UIFont systemFontOfSize:12]];
    SearchText.textColor=[UIColor whiteColor];
    [SearchText.layer setCornerRadius:4.0];
    [SearchText resignFirstResponder];
    [SearchText setAutocorrectionType:UITextAutocorrectionTypeNo];
    [SearchText setTextAlignment:NSTextAlignmentCenter];
    
//    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 10, 35, 25)];
//    SearchText.leftView = paddingView;
//    SearchText.leftViewMode = UITextFieldViewModeAlways;
    [SearchText setDelegate:(id)self];
    [searchView addSubview: SearchText];
    
    float dx = 15, dy = SearchText.frame.origin.y+SearchText.frame.size.height+5, dw = 50 , dh = 50;
    
    for (int i = 0; i<3; i++)
    {
        UIImageView *imageView = [[UIImageView alloc]init];
        [imageView setFrame:CGRectMake(dx, dy, dw, dh)];
        [imageView setBackgroundColor:[UIColor grayColor]];
        [imageView.layer setBorderWidth:1.0];
        [imageView.layer setCornerRadius:25];
        [imageView.layer setBorderColor:[UIColor colorWithRed:0/255.0 green:170/255.0 blue:176/255.0 alpha:1.0].CGColor];
        [searchView addSubview:imageView];
        
        dx = dx+dw+5;
        
    }
    
    mapKitView = [[MKMapView alloc]init];
    [mapKitView setFrame:CGRectMake(0, searchView.frame.size.height, searchView.frame.size.width, self.view.frame.size.height-(searchView.frame.size.height+50))];
    [mapKitView setDelegate:(id)self];
    CLLocationCoordinate2D noLocation = CLLocationCoordinate2DMake([[kAppDelegate latitude]floatValue], [[kAppDelegate longitude]floatValue]);
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(noLocation, 50000, 50000); //Set zooming level
    MKCoordinateRegion adjustedRegion = [mapKitView regionThatFits:viewRegion]; //add location to map
    [mapKitView setRegion:adjustedRegion animated:YES];
    [self.view addSubview:mapKitView];
     
}


-(BOOL)textFieldShouldReturn:(UITextField*)textField
{
    [textField resignFirstResponder];
    return YES;
}





- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}


@end
