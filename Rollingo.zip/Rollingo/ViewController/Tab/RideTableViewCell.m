//
//  RideTableViewCell.m
//  Rollingo
//
//  Created by Popin kumar on 5/23/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "RideTableViewCell.h"

@implementation RideTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    
}
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        
        self.profileImageView = [[UIImageView alloc]init];
        [self.profileImageView setClipsToBounds:NO];
        [self.profileImageView setBackgroundColor:[UIColor redColor]];
        [self.profileImageView.layer setCornerRadius:30.0];
        [self.profileImageView.layer setBorderWidth:1.0];
        [self.profileImageView.layer setBorderColor:[UIColor grayColor].CGColor];
        [self addSubview:self.profileImageView];
        
        self.timeLabel =[[UILabel alloc]init];
        [self.timeLabel setFont:[UIFont systemFontOfSize:12]];
        [self.timeLabel setTextAlignment:NSTextAlignmentCenter];
        [self.timeLabel setTextColor:[UIColor redColor]];
        [self addSubview:self.timeLabel];
        
        self.rideNameLabel =[[UILabel alloc]init];
        [self.rideNameLabel setFont:[UIFont systemFontOfSize:14]];
        [self.rideNameLabel setTextColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0]];
        [self.rideNameLabel setTextAlignment:NSTextAlignmentLeft];
        [self addSubview:self.rideNameLabel];
        
        self.resionNameLabel =[[UILabel alloc]init];
        [self.resionNameLabel setFont:[UIFont systemFontOfSize:8]];
        [self.resionNameLabel setTextColor:[UIColor grayColor]];
        [self.resionNameLabel setTextAlignment:NSTextAlignmentLeft];
        [self addSubview:self.resionNameLabel];
        
        self.resiondecribeLabel =[[UILabel alloc]init];
        [self.resiondecribeLabel setFont:[UIFont systemFontOfSize:8]];
        [self.resiondecribeLabel setTextColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0]];
        [self.resiondecribeLabel setTextAlignment:NSTextAlignmentLeft];
        [self addSubview:self.resiondecribeLabel];
        
        self.scrollView = [[UIScrollView alloc]init];
        [self.scrollView setBackgroundColor:[UIColor clearColor]];
        self.scrollView.scrollEnabled=NO;
        self.scrollView.userInteractionEnabled=YES;
        [self.scrollView setClipsToBounds:YES];
        // [self.scrollView setContentSize:CGSizeMake(1000, 0)];
        self.scrollView.showsHorizontalScrollIndicator=NO;
        [self addSubview:self.scrollView];
        
        self.hoursetimeLabel =[[UILabel alloc]init];
        [self.hoursetimeLabel setFont:[UIFont systemFontOfSize:12]];
        [self.hoursetimeLabel setTextAlignment:NSTextAlignmentCenter];
        [self.hoursetimeLabel setTextColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0]];
        [self addSubview:self.hoursetimeLabel];

        self.rideiconImageView = [[UIImageView alloc]init];
      
        [self addSubview:self.rideiconImageView];
                
        
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

   
}

@end
