//
//  NotificationTableViewCell.m
//  Rollingo
//
//  Created by Popin kumar on 5/29/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "NotificationTableViewCell.h"

@implementation NotificationTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
   
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
 
        self.profileImageView = [[UIImageView alloc]init];
        [self.profileImageView setClipsToBounds:NO];
        [self.profileImageView setBackgroundColor:[UIColor redColor]];
        [self.profileImageView.layer setCornerRadius:30.0];
        [self.profileImageView.layer setBorderWidth:1.0];
        [self.profileImageView.layer setBorderColor:[UIColor grayColor].CGColor];
        [self addSubview:self.profileImageView];
        
        self.timeLabel =[[UILabel alloc]init];
        [self.timeLabel setFont:[UIFont systemFontOfSize:12]];
        [self.timeLabel setTextAlignment:NSTextAlignmentCenter];
        [self.timeLabel setTextColor:[UIColor grayColor]];
        [self addSubview:self.timeLabel];
        
//        self.profileNameLabel =[[UILabel alloc]init];
//        [self.profileNameLabel setFont:[UIFont systemFontOfSize:14]];
//        [self.profileNameLabel setTextColor:[UIColor colorWithRed:0/255.0 green:82/255.0 blue:107/255.0 alpha:1.0]];
//        [self.profileNameLabel setTextAlignment:NSTextAlignmentLeft];
//        [self addSubview:self.profileNameLabel];
        
        self.masgLabel =[[UILabel alloc]init];
        [self.masgLabel setFont:[UIFont systemFontOfSize:11]];
        [self.masgLabel setTextColor:[UIColor grayColor]];
        [self.masgLabel setTextAlignment:NSTextAlignmentLeft];
        [self addSubview:self.masgLabel];
        
        self.approveButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.approveButton];
        
        self.rejectButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:self.rejectButton];
  
        
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    
}

@end
