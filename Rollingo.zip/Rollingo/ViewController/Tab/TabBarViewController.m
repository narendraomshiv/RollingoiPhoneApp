//
//  TabBarViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "TabBarViewController.h"
#import "LoginViewController.h"
#import "HomeEventViewController.h"
#import "EventRideViewController.h"
#import "NotificationViewController.h"
#import "ProfileViewController.h"
#import "AroundViewController.h"


@interface TabBarViewController ()

@end

@implementation TabBarViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self viewWillLayoutSubviews];
    
    
    
    [[UITabBar appearance] setBarTintColor:[UIColor whiteColor]];
    self.tabBarController.delegate = self;
    [[UITabBar appearance] setTintColor:[UIColor colorWithRed:202/255.0 green:0/255.0 blue:11/255.0 alpha:1.0]];
    
    
    HomeEventViewController *home=[[HomeEventViewController alloc]init];
    EventRideViewController *ride=[[EventRideViewController alloc]init];
    NotificationViewController *notification=[[NotificationViewController alloc]init];
    AroundViewController *around=[[AroundViewController alloc]init];
    ProfileViewController *profile=[[ProfileViewController alloc]init];
    
  
    NSArray *array1=[[NSArray alloc]initWithObjects:home,ride,notification,around,profile,nil];
    
    
    [self setViewControllers:array1];
    
    home.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"EVENTS" image:[UIImage imageNamed:@"event_i5"] tag:0];
    [home.tabBarItem setTitlePositionAdjustment:UIOffsetMake(0, -4)];
    
    
    ride.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"MY RIDES" image:[UIImage imageNamed:@"ride_i5"] tag:1];
    [ride.tabBarItem setTitlePositionAdjustment:UIOffsetMake(0, -4)];
    
    
    notification.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"NOTIFICATION" image:[UIImage imageNamed:@"noti_i5"] tag:2];
    [notification.tabBarItem setTitlePositionAdjustment:UIOffsetMake(0, -4)];
    
    
    around.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"AROUND" image:[UIImage imageNamed:@"around_i5"] tag:3];
    [around.tabBarItem setTitlePositionAdjustment:UIOffsetMake(0, -4)];
    
    profile.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"PROFILE" image:[UIImage imageNamed:@"iconpro_i5"] tag:4];
    [around.tabBarItem setTitlePositionAdjustment:UIOffsetMake(0, -4)];
  
}




- (void)viewWillLayoutSubviews
{
    CGRect tabFrame = self.tabBar.frame;
    tabFrame.size.height = 60;
    tabFrame.origin.y = self.view.frame.size.height -60;
    self.tabBar.frame = tabFrame;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    
}



@end
