//
//  HomeTableViewCell.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "HomeTableViewCell.h"

@implementation HomeTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    
}
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        self.fullcellView = [[UIView alloc]init];
        [self.fullcellView setBackgroundColor:[UIColor whiteColor]];
        [self.fullcellView.layer setBorderWidth:1.0];
        [self.fullcellView.layer setBorderColor:[UIColor grayColor].CGColor];
        [self.fullcellView.layer setCornerRadius:10.0];
        [self addSubview:self.fullcellView];
        
        self.resturantImageView = [[UIImageView alloc]init];
        [self.resturantImageView setClipsToBounds:NO];
        [self.resturantImageView setBackgroundColor:[UIColor redColor]];
        [self.resturantImageView.layer setCornerRadius:10.0];
        [self.fullcellView addSubview:self.resturantImageView];
        
        self.restaurantNameLabel =[[UILabel alloc]init];
        [self.restaurantNameLabel setFont:[UIFont fontWithName:@"hobo" size:16]];
        [self.restaurantNameLabel setTextAlignment:NSTextAlignmentCenter];
        [self.restaurantNameLabel setTextColor:[UIColor whiteColor]];
        [self.resturantImageView addSubview:self.restaurantNameLabel];
        
        self.timeLabel =[[UILabel alloc]init];
        [self.timeLabel setFont:[UIFont systemFontOfSize:12]];
        [self.timeLabel setTextColor:[UIColor whiteColor]];
        [self.timeLabel setTextAlignment:NSTextAlignmentCenter];
        [self.resturantImageView addSubview:self.timeLabel];
        
        
        self.showiconView = [[UIView alloc]init];
        [self.showiconView setBackgroundColor:[UIColor whiteColor]];
        [self.fullcellView addSubview:self.showiconView];

        self.goingImageView = [[UIImageView alloc]init];
        [self.showiconView addSubview:self.goingImageView];
        
        self.mutualImageView = [[UIImageView alloc]init];
        [self.showiconView addSubview:self.mutualImageView];
        
        self.rideImageView = [[UIImageView alloc]init];
        [self.showiconView addSubview:self.rideImageView];
        
        self.goingLabel =[[UILabel alloc]init];
        [self.goingLabel setFont:[UIFont systemFontOfSize:12]];
        [self.goingLabel setTextColor:[UIColor grayColor]];
        [self.showiconView addSubview:self.goingLabel];
        
        self.mutualLabel =[[UILabel alloc]init];
        [self.mutualLabel setFont:[UIFont systemFontOfSize:12]];
        [self.mutualLabel setTextColor:[UIColor grayColor]];
        [self.showiconView addSubview:self.mutualLabel];
        
        self.rideLabel =[[UILabel alloc]init];
        [self.rideLabel setFont:[UIFont systemFontOfSize:12]];
        [self.rideLabel setTextColor:[UIColor grayColor]];
        [self.showiconView addSubview:self.rideLabel];
       
        
        
        self.scrollView = [[UIScrollView alloc]init];
        [self.scrollView setBackgroundColor:[UIColor clearColor]];
        self.scrollView.scrollEnabled=NO;
        self.scrollView.userInteractionEnabled=YES;
        [self.scrollView setClipsToBounds:YES];
       // [self.scrollView setContentSize:CGSizeMake(1000, 0)];
        self.scrollView.showsHorizontalScrollIndicator=NO;
        [self.fullcellView addSubview:self.scrollView];
        
             
        self.scrollButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.scrollButton setBackgroundColor:[UIColor clearColor]];
        [self.scrollButton setClipsToBounds:YES];
        [self.scrollView addSubview:self.scrollButton];
        
        //=====================================================================
        
        
       
        self.dilButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.resturantImageView addSubview:self.dilButton];
  
    
        
        
            
    }
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    
}

@end
