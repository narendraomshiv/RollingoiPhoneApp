//
//  LoginViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "LoginViewController.h"
#import "TabBarViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"background_i5"]]];
    
    [self LoginView];
   
}


-(void)LoginView
{
    UIImage  *fImg = [UIImage imageNamed:@"fIcon_i5"];
    UIButton *faceebookButton = [self addButtonWithFrame:CGRectMake(25, self.view.frame.size.height/2+170, self.view.frame.size.width-50, 46) tag:1 title:@"Login with Facebook" font:[UIFont fontWithName:@"Hobo" size:24] titleColor:[UIColor whiteColor]];
   
    [faceebookButton setBackgroundColor:[UIColor colorWithRed:0/255.0 green:117/255.0 blue:206/255.0 alpha:1.0]];
    
    [faceebookButton setImage:fImg forState:UIControlStateNormal];
    
  //  [faceebookButton setImageEdgeInsets:UIEdgeInsetsMake(<#CGFloat top#>, <#CGFloat left#>, <#CGFloat bottom#>, <#CGFloat right#>)];
    [faceebookButton setImageEdgeInsets:UIEdgeInsetsMake(0, -50, 0, 0)];
    [faceebookButton setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [self.view addSubview:faceebookButton];
    
}



-(UIButton*)addButtonWithFrame:(CGRect)frame tag:(int)tag title:(NSString*)title font:(UIFont*)font titleColor:(UIColor*)titlecolor
{
    UIButton *button = [[UIButton alloc]init];
    [button setFrame:frame];
    [button setTag:tag];
    [button addTarget:self action:@selector(loginbuttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [button.titleLabel setFont:font];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:titlecolor forState:UIControlStateNormal];
    return button;
  
}

-(IBAction)loginbuttonAction:(UIButton*)sender
{
    TabBarViewController *tab = [TabBarViewController new];
    [self.navigationController pushViewController:tab animated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}



@end
