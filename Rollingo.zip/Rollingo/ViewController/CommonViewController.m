//
//  CommonViewController.m
//  Rollingo
//
//  Created by Popin kumar on 5/22/17.
//  Copyright © 2017 Popin kumar. All rights reserved.
//

#import "CommonViewController.h"

@interface CommonViewController ()

@end

@implementation CommonViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self commonView];
    
}

-(void)commonView
{
    
    //UIImage *navImg = [UIImage imageNamed:@"head_i6p"];
    self.navigationView=[[UIView alloc]initWithFrame:CGRectMake(0, 0,self.view.frame.size.width,65)];
    self.navigationView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"head_i5"]];
    [self.view addSubview:self.navigationView];
    
    self.headerLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,self.navigationView.frame.size.height)];
    [self.headerLabel setText:@"Rollingo"];
    [self.headerLabel setTextColor:[UIColor whiteColor]];
    [self.headerLabel setTextAlignment:NSTextAlignmentCenter];
    self.headerLabel.font=[UIFont fontWithName:@"Montserrat-Bold" size:16];
    [self.navigationView addSubview: self.headerLabel];
    
    UIImage * backImage = [UIImage imageNamed:@"back_i5"];
    self.backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.backButton setFrame:CGRectMake(0, 0, 60, self.navigationView.frame.size.height-5)];
    [self.backButton setTag:400];
    [self.backButton setImage:backImage forState:UIControlStateNormal];
    [self.backButton addTarget:self action:@selector(backButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.backButton setBackgroundColor:[UIColor clearColor]];
    [self.navigationView addSubview:self.backButton];
    
}




-(void)backButtonAction:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];

}



@end
